-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 09, 2021 at 04:15 AM
-- Server version: 10.4.20-MariaDB-log
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `1096969`
--

-- --------------------------------------------------------

--
-- Table structure for table `nac_hw_subjectList`
--

CREATE TABLE `nac_hw_subjectList` (
  `subjectId` tinytext NOT NULL,
  `subjectName` longtext NOT NULL,
  `subjectImg` text NOT NULL,
  `subjectEnabled` tinyint(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nac_hw_subjectList`
--

INSERT INTO `nac_hw_subjectList` (`subjectId`, `subjectName`, `subjectImg`, `subjectEnabled`) VALUES
('ท31101', 'ภาษาไทย', 'https://static.thairath.co.th/media/4DQpjUtzLUwmJZZSC4zFdxhkAhb7hDVcqUVM1Ldezisd.jpg', 1),
('ค31101', 'คณิตศาสตร์', 'https://img.my-best.in.th/press_component/images/0d073a73445d2a05b7a8222aa298ba1f.jpg', 1),
('ว30105', 'วิทยาศาสตร์ชีวภาพ', 'https://s3-ap-southeast-1.amazonaws.com/wordpresstueetor/blog/th/wp-content/uploads/2020/08/%E0%B8%AA%E0%B8%AD%E0%B8%99%E0%B8%A7%E0%B8%B4%E0%B8%97%E0%B8%A2%E0%B8%B2%E0%B8%A8%E0%B8%B2%E0%B8%AA%E0%B8%95%E0%B8%A3%E0%B9%8C-%E0%B8%AB%E0%B8%B2%E0%B8%A3%E0%B8%B2%E0%B8%A2%E0%B9%84%E0%B8%94%E0%B9%89%E0%B8%9E%E0%B8%B4%E0%B9%80%E0%B8%A8%E0%B8%A9-750x375.jpg', 1),
('ส31101', 'หน้าที่พลเมือง', 'https://sites.google.com/site/nateeponlameungdee/_/rsrc/1536131906184/home/maxresdefault.jpg', 1),
('ส31102', 'พระพุทธศาสนา', 'https://ik.imagekit.io/romdee/wp-content/uploads/2018/10/%E0%B8%AB%E0%B8%A5%E0%B8%B1%E0%B8%81%E0%B8%98%E0%B8%A3%E0%B8%A3%E0%B8%A1%E0%B9%83%E0%B8%99%E0%B8%9E%E0%B8%B8%E0%B8%97%E0%B8%98%E0%B8%A8%E0%B8%B2%E0%B8%AA%E0%B8%99%E0%B8%B2.jpg', 1),
('พ31101', 'สุขศึกษา', 'https://sites.google.com/site/crwathnkhotrphunga/_/rsrc/1472860622412/home/dsdlogo.jpg', 1),
('ศ31101', 'ศิลปะ', 'https://www.niceandfitgallery.com/wp-content/uploads/2018/01/artis-pain.jpg', 1),
('ง31101', 'การงานอาชีพฯ', 'https://sites.google.com/site/phimphitcha46/_/rsrc/1444450178183/bth-thi-1/46100568_0_20130409-223937.jpg', 1),
('อ31101', 'ภาษาอังกฤษ', 'https://teen.mthai.com/app/uploads/2016/07/1-445x300.png', 1),
('ว31101', 'วิทยาการคำนวณและออกแบบ', 'https://suithataporn.files.wordpress.com/2019/05/computing.png', 1),
('ค31201', 'คณิตศาสตร์เพิ่มเติม', 'https://www.scimath.org/images/2017/article/November/7577/7577-1.jpg', 1),
('ว31201', 'ฟิสิกส์ 1', 'https://www.chula.ac.th/wp-content/uploads/2018/03/cu_inside_14112016.jpg', 1),
('ว31221', 'เคมี 1', 'https://ichef.bbci.co.uk/news/640/cpsprodpb/D319/production/_110014045_atomsgettyimages.png', 1),
('ว31241', 'ชีววิทยา 1', 'https://dissertationtop.com/wp-content/uploads/2020/05/biology-dissertation-topics.jpg', 1),
('อ31201', 'ภาษาอังกฤษอ่าน-เขียน 1', 'https://d3f1iyfxxz8i1e.cloudfront.net/courses/course_image/466f09a220bf.jpg', 1),
('อ20315', 'สนทนาภาษาอังกฤษ 1', 'https://assets.rebelmouse.io/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpbWFnZSI6Imh0dHBzOi8vYXNzZXRzLnJibC5tcy8xOTI5NjM5MS9vcmlnaW4uanBnIiwiZXhwaXJlc19hdCI6MTY2MzY0NDc1Nn0.uxtlQp_hIAzpdS8vTWiHpAC3CaIRiRfa5B2gKQQ7P38/img.jpg?width=1200&coordinates=0%2C83%2C0%2C84&height=600', 1),
('พ30201', 'พลศึกษา', 'https://www.thenorthlines.com/wp-content/uploads/2020/05/Capture12254646.jpg', 1),
('ส30201', 'อาเซียนศึกษา', 'https://upload.wikimedia.org/wikipedia/th/thumb/8/87/Flag_of_ASEAN.svg/1200px-Flag_of_ASEAN.svg.png', 1),
('ว30281', 'เทคโนโลยีสร้างสรรค์ 1', 'https://www.xsabaidee.com/th/images/articles/it_infra/image1-1.jpg', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
