-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 09, 2021 at 04:14 AM
-- Server version: 10.4.20-MariaDB-log
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `1096969`
--

-- --------------------------------------------------------

--
-- Table structure for table `nac_hw_account`
--

CREATE TABLE `nac_hw_account` (
  `studentNumber` tinyint(4) NOT NULL,
  `studentId` mediumint(9) NOT NULL,
  `studentName` longtext DEFAULT NULL,
  `studentLastName` longtext DEFAULT NULL,
  `password` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nac_hw_account`
--

INSERT INTO `nac_hw_account` (`studentNumber`, `studentId`, `studentName`, `studentLastName`, `password`) VALUES
(1, 17866, 'กฤติน', 'ไวยาพัฒนกร', 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(2, 17869, 'ธนภัทร', 'กายเมืองปัก', 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(3, 17870, 'ธันยธรณ์', 'เกศเมตตา', 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(4, 17871, 'นรสีห์', 'ด่านศิริชัยสวัสดิ์', 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(5, 17876, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(6, 17904, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(7, 17906, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(8, 17908, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(9, 17915, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(10, 17951, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(11, 17952, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(12, 17985, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(13, 17995, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(14, 17998, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(15, 18038, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(16, 18042, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(17, 18070, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(18, 18078, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(19, 18118, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(20, 18122, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(21, 18128, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(22, 18129, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(23, 18155, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(24, 18195, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(25, 18236, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(26, 18241, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(27, 18270, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(28, 18304, 'ทีปดา', 'ชื่นเปรมปรีดิ์', '576bd659e9b7da5e39616226e2af384cf137067c'),
(29, 19184, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(30, 20195, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(31, 20196, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(32, 20198, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(33, 20199, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(34, 17892, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(35, 17927, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(36, 17973, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(37, 18015, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(38, 18020, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(39, 18094, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(40, 18102, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(41, 18138, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(42, 18172, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(43, 18221, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409'),
(44, 20197, NULL, NULL, 'b7d5c740142da1b188db57bf3fa6ebeeb2df1409');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
